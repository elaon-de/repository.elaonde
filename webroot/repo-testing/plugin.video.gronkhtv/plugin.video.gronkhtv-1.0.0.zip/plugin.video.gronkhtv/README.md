# Kodi Addon GronkhTv

Inoffizielles Kodi-Addon zum Abrufen der Inhalte der [http://gronkh.tv](gronkh.tv) Streamarchiv Seite.




API URL's:

* https://api.gronkh.tv/v1/search?first=24&direction=desc&sort=date
* https://api.gronkh.tv/v1/video/discovery/recent
* https://api.gronkh.tv/v1/video/discovery/views
* https://api.gronkh.tv/v1/video/info?episode=1064
* https://api.gronkh.tv/v1/video/playlist?episode=1064
* https://api.gronkh.tv/v1/tags/all



## License

This project is primarily licensed under the **MIT License**.

You are free to use, modify, distribute and sublicense this software under the terms of the MIT License.

---

## Third-Party Licenses

### Font Awesome Icons

All icons located in:
`resources/media/`
are derived from **Font Awesome Free** and are **not covered by the MIT license of this project**.

Font Awesome Free is licensed as follows:

- **Icons (SVG, JS):** Creative Commons Attribution 4.0 International (CC BY 4.0)  

You may use the icons commercially and modify them, but **attribution is required** according to the CC BY 4.0 license. :contentReference[oaicite:0]{index=0}

More information:  
https://fontawesome.com/license/free

---

### Application Icons

The following files:
```
icon.png
favicon.png
```

are licensed under **Creative Commons Attribution-NonCommercial (CC BY-NC)**.

You may:

- use
- modify
- redistribute

these files **only for non-commercial purposes**.

Commercial use is **not permitted** without explicit permission from the author.

---

## Summary

| Component | License |
|---|---|
| Source code | MIT License |
| Icons in `resources/media` | Font Awesome Free (CC BY 4.0) |
| `icon.png`, `favicon.png` | CC BY-NC (non-commercial only) |

---

## Attribution

If you redistribute this project including the icons, please include the following attribution:

> Icons by **Font Awesome** (https://fontawesome.com) licensed under **CC BY 4.0**.
