# Kodi Addon GronkhTv

Inoffizielles Kodi-Addon zum Abrufen der Inhalte der [gronkh.tv](https://gronkh.tv) Streamarchiv Seite.



## Voraussetzungen
 
- Kodi **19 (Matrix)** oder höher
- Internetverbindung
---


## Installation über ElaonDe Kodi Repo
 
Das Addon wird über das **ElaonDe Kodi Repository** bereitgestellt. Es gibt zwei Varianten:
 
| | Stable Repo | Testing Repo |
|---|---|---|
| **Zweck** | Stabile, getestete Releases | Vorabversionen & Bugfixes |
| **Empfohlen für** | Alle Nutzer | Tester & Entwickler |
| **ZIP-URL** | [https://kodirepo.elaon.de/repository.elaonde-1.0.0.zip](https://kodirepo.elaon.de/repository.elaonde-1.0.0.zip) | [https://kodirepo.elaon.de/repository.elaondetesting-1.0.0.zip](https://kodirepo.elaon.de/repository.elaondetesting-1.0.0.zip) |
 
> ⚠️ **Hinweis:** Das Testing Repo kann instabile oder unfertige Versionen enthalten. Für den normalen Gebrauch wird das Stable Repo empfohlen.
 
---

### 📦 Stable Repo
 
Verwende dieses Repo für stabile, produktionsreife Versionen des Addons.
 
- **ZIP-Datei:** `repository.elaonde-x.x.x.zip` (auf https://kodirepo.elaon.de/repository.elaonde-1.0.0.zip verfügbar)
### 🧪 Testing Repo
 
Verwende dieses Repo, um neue Features frühzeitig zu testen oder Bugs zu melden.
 
- **ZIP-Datei:** `repository.elaondetesting-x.x.x.zip` (auf https://kodirepo.elaon.de/repository.elaondetesting-1.0.0.zip verfügbar)
---


## Methode 1: ZIP herunterladen und manuell installieren
 
Diese Methode eignet sich, wenn du kein Netzwerklaufwerk einrichten möchtest oder kannst.
 
### Schritt 1 – ZIP herunterladen
 
Besuche **https://kodirepo.elaon.de/** und lade die gewünschte Repository-ZIP herunter:

- Stable: `repository.elaonde-x.x.x.zip`
- Testing: `repository.elaondetesting-x.x.x.zip`

![ElaonDE Repoansicht im Browser](docs/screenshots/elaonde_repo.png)
 
---

### Schritt 2 – ZIP auf dein Gerät kopieren
 
Kopiere die heruntergeladene ZIP-Datei an einen Ort, den Kodi erreichen kann, z. B.:
 
- **USB-Stick**
- **Interner Speicher** (z. B. `Downloads`-Ordner)
- **Netzlaufwerk**
---


### Schritt 3 – Kodi öffnen und zu den Einstellungen navigieren
 
1. Öffne **Kodi**
2. Gehe zu ⚙️ **Einstellungen** → **System** → **Add-ons**
3. Aktiviere **„Unbekannte Quellen"**, falls noch nicht aktiv

![Kodi Einstellung Unbekannte Quellen](docs/screenshots/kodi_allow_unknown_src.png)
 
---

### Schritt 4 – Repository aus ZIP installieren
 
1. Gehe zurück zum **Kodi Startbildschirm**
2. Wähle ➕ **Add-ons** → **Add-on Browser** (Schachtelbox-Symbol oben links)
3. Klicke auf **„Aus ZIP-Datei installieren"**
4. Navigiere zur heruntergeladenen ZIP-Datei und wähle sie aus

![Kodi Addon-Browser - Aus ZIP-Datei installieren ausgewählt](docs/screenshots/kodi_addonbrowser_fromzip.png)
 
![Kodi Addon-Browser - Aus Zip-Datei installieren - repository.elaonde-1.0.0.zip ausgewählt](docs/screenshots/kodi_addonbrowser_selectedrepozip.png)
 
5. Warte auf die Bestätigung: **„ElaonDe Repository wurde installiert"**
![Kodi Addon-Browser - Repository erfolgreich installiert Meldung](docs/screenshots/kodi_addonbrowser_repo_installed.png)
 
✅ Das Repo ist jetzt installiert – weiter zu [Addon installieren](#addon-installieren).
 
--


## Methode 2: Repo als Quelle hinzufügen (empfohlen)
 
Mit dieser Methode fügt Kodi das Repository direkt über die URL hinzu – du brauchst nichts manuell herunterzuladen.
 
### Schritt 1 – Dateimanager öffnen
 
1. Öffne **Kodi**
2. Gehe zu ⚙️ **Einstellungen** → **Dateimanager**
3. Klicke auf **„Quelle hinzufügen"**

![Kodi Dateimanager - Quelle hinzufügen](docs/screenshots/kodi_filemanager_add_src.png)
 
---

### Schritt 2 – URL eingeben
 
1. Klicke auf **`<Kein>`** (das leere Feld)
2. Gib die URL des Repos ein:
   ```
   https://kodirepo.elaon.de/
   ```

![Kodi Dateimanager - Quelle hinzufügen Dialog](docs/screenshots/kodi_add_src.png)
![Kodi Dateimanager - Quelle hinzufügen URL eingeben](docs/screenshots/kodi_add_src_inputfield.png)
 
3. Vergib einen Namen für die Quelle, z. B. `ElaonDe Repo`
4. Klicke auf **OK**
![Kodi Dateimanager - Quelle hinzufügen Dialog ausgefüllt](docs/screenshots/kodi_add_src_filled.png)
 
---

### Schritt 3 – Repository aus Quelle installieren
 
1. Gehe zu **Add-ons** → **Add-on Browser** (Schachtelbox-Symbol)
2. Klicke auf **„Aus ZIP-Datei installieren"**
3. Wähle die soeben hinzugefügte Quelle (`ElaonDE-Repo`)
4. Wähle die Repository-ZIP-Datei aus der Liste
![Kodi Addon-Browser - Aus Zip-Datei installieren - repository.elaonde-1.0.0.zip ausgewählt](docs/screenshots/kodi_addonbrowser_selectedrepozip.png)
 
5. Warte auf die Bestätigung: **„ElaonDe Repository wurde installiert"**
✅ Das Repo ist jetzt installiert – weiter zum nächsten Abschnitt.
 
---

## Addon installieren
 
Sobald das Repository installiert ist, kannst du das Addon direkt darüber installieren:
 
1. Gehe zu **Add-ons** → **Add-on Browser**
2. Klicke auf **„Aus Repository installieren"**
3. Wähle **„ElaonDe Repository"** (Stable oder Testing)
4. Navigiere zur passenden Kategorie (z. B. **Video-Add-ons**)
5. Wähle **[Addon-Name]** und klicke auf **„Installieren"**
![Kodi Video-Addons - Ansicht Gronkh.tv Addon im ElaonDE-Repo](docs/screenshots/kodi_install_from_repo_addon-gronkhtv.png)
 
6. Kodi installiert das Addon und alle Abhängigkeiten automatisch.
 
---

## Lizenz

Dieses Projekt steht hauptsächlich unter der **MIT-Lizenz**.

Es ist gestattet, diese Software unter den Bedingungen der MIT-Lizenz frei zu verwenden, zu verändern, zu verteilen und weiterzulizenzieren.

---

## Drittanbieter-Lizenzen

### Font Awesome Icons

Alle Icons im Verzeichnis:
`resources/media/`
basieren auf **Font Awesome Free** und sind **nicht durch die MIT-Lizenz dieses Projekts abgedeckt**.

Font Awesome Free ist wie folgt lizenziert:

- **Icons (SVG, JS):** Creative Commons Namensnennung 4.0 International (CC BY 4.0)

Die Icons dürfen kommerziell genutzt und verändert werden, jedoch ist gemäß der CC-BY-4.0-Lizenz eine **Namensnennung erforderlich**.

Weitere Informationen:
https://fontawesome.com/license/free

---

### Anwendungs-Icons

Die folgenden Dateien:
```
icon.png
favicon.png
```

stehen unter der Lizenz **Creative Commons Namensnennung – Nicht kommerziell (CC BY-NC)**.

Folgendes ist gestattet:

- Verwenden
- Verändern
- Weitergeben

jedoch ausschließlich **für nicht-kommerzielle Zwecke**.

Eine kommerzielle Nutzung ist **ohne ausdrückliche Genehmigung des Autors nicht zulässig**.

---

## Zusammenfassung

| Komponente | Lizenz |
|---|---|
| Quellcode | MIT-Lizenz |
| Icons in `resources/media` | Font Awesome Free (CC BY 4.0) |
| `icon.png`, `favicon.png` | CC BY-NC (nur nicht-kommerziell) |

---

## Namensnennung

Wenn dieses Projekt einschließlich der Icons weiterverbreitet wird, ist folgende Quellenangabe anzugeben:

> Icons von **Font Awesome** (https://fontawesome.com), lizenziert unter **CC BY 4.0**.


---




# English version below


# Kodi Addon GronkhTv
Unofficial Kodi addon for accessing the content of the [gronkh.tv](https://gronkh.tv) stream archive.



## License

This project is primarily licensed under the **MIT License**.

You are free to use, modify, distribute and sublicense this software under the terms of the MIT License.

---

## Third-Party Licenses

### Font Awesome Icons

All icons located in:
`resources/media/`
are derived from **Font Awesome Free** and are **not covered by the MIT license of this project**.

Font Awesome Free is licensed as follows:

- **Icons (SVG, JS):** Creative Commons Attribution 4.0 International (CC BY 4.0)  

You may use the icons commercially and modify them, but **attribution is required** according to the CC BY 4.0 license. :contentReference[oaicite:0]{index=0}

More information:  
https://fontawesome.com/license/free

---

### Application Icons

The following files:
```
icon.png
favicon.png
```

are licensed under **Creative Commons Attribution-NonCommercial (CC BY-NC)**.

You may:

- use
- modify
- redistribute

these files **only for non-commercial purposes**.

Commercial use is **not permitted** without explicit permission from the author.

---

## Summary

| Component | License |
|---|---|
| Source code | MIT License |
| Icons in `resources/media` | Font Awesome Free (CC BY 4.0) |
| `icon.png`, `favicon.png` | CC BY-NC (non-commercial only) |

---

## Attribution

If you redistribute this project including the icons, please include the following attribution:

> Icons by **Font Awesome** (https://fontawesome.com) licensed under **CC BY 4.0**.
