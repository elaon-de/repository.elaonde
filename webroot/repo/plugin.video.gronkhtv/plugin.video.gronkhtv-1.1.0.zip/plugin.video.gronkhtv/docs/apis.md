# Verwendete und vorhandene API's


API URL's:

Ab 8.6.26:
* https://backend.gronkh.tv/v3/videos/discovery/newest
* https://backend.gronkh.tv/v3/videos/discovery/random
* https://backend.gronkh.tv/v3/videos/discovery/hot
* https://backend.gronkh.tv/v3/promoted/streams
* https://backend.gronkh.tv/v3/videos/episode/1096
* https://backend.gronkh.tv/v3/tags
* POST https://backend.gronkh.tv/v3/videos/search (json übergabe: {"order":"created_at","dir":"desc","page":1})
    - Order types:
    * created_at
    * meta_length
    * views
    * season
    * episode
    * title
    - dir types:
    * desc
    * asc
    - "after":"2026-06-01T00:00:00.000+02:00"
    - "before":"2026-06-06T23:59:59.999+02:00"
    - "tags":["6"]


Alte API-URL's:


* https://api.gronkh.tv/v1/search?first=24&direction=desc&sort=date
* https://api.gronkh.tv/v1/video/discovery/recent
* https://api.gronkh.tv/v1/video/discovery/views
* https://api.gronkh.tv/v1/video/info?episode=1064
* https://api.gronkh.tv/v1/video/playlist?episode=1064
* https://api.gronkh.tv/v1/tags/all

